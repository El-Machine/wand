//
//  toolburator_Tests.swift
//  toolburator_Tests
//
//  Created by Alex Kozin on 28.04.2022.
//  Copyright © 2022 El Machine. All rights reserved.
//

import UIKit.UIFeedbackGenerator

import XCTest

//Disable: "Execute in parallel (if possible)" before
class UIFeedbackGenerator_Tests: XCTestCase {

    override func setUpWithError() throws {
        srand48(Date.self|)
    }

    func test_Impact() throws {
        let intensity = drand48()

        let generator = UIImpactFeedbackGenerator.self|
        generator | intensity

        wait(for: expectation(), with: "Impact occured?", message: "\(intensity)")
    }

    func test_Notification() throws {
        let type = UINotificationFeedbackGenerator.FeedbackType.allCases.randomElement()!

        let generator = UINotificationFeedbackGenerator.self|
        generator | type

        wait(for: expectation(), with: "Notification occured?", message: "👋🏽 \(type.rawValue)")
    }

    func test_Selection() throws {
        let generator = UISelectionFeedbackGenerator.self|
        generator|

        wait(for: expectation(), with: "Selection occured?", message: "𛲝 ")
    }

    private func wait(for expectation: XCTestExpectation,
                      with title: String,
                      message: String) {

        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "📳",
                                      style: .default,
                                      handler: { _ in
            expectation.fulfill()
        }))
        UIApplication.shared.visibleViewController?.present(alert, animated: true)

        waitForExpectations(timeout: .default * 2)
    }

}

extension UINotificationFeedbackGenerator.FeedbackType: CaseIterable {

    public static var allCases: [Self] = [.success,
                                          .warning,
                                          .error]

}
